import React from 'react'

const Header = () => {
  return (
    <h2>
     Refined Stack Expense Tracker
    </h2>
  )
}

export default Header
